--
-- PostgreSQL database dump
--

SET client_encoding = 'UTF8';
SET standard_conforming_strings = off;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET escape_string_warning = off;

SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: posts; Type: TABLE; Schema: public; Owner: bojnfnlxob; Tablespace: 
--

CREATE TABLE posts (
    id integer NOT NULL,
    name character varying(255),
    message text,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.posts OWNER TO bojnfnlxob;

--
-- Name: posts_id_seq; Type: SEQUENCE; Schema: public; Owner: bojnfnlxob
--

CREATE SEQUENCE posts_id_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.posts_id_seq OWNER TO bojnfnlxob;

--
-- Name: posts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: bojnfnlxob
--

ALTER SEQUENCE posts_id_seq OWNED BY posts.id;


--
-- Name: posts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: bojnfnlxob
--

SELECT pg_catalog.setval('posts_id_seq', 194, true);


--
-- Name: schema_migrations; Type: TABLE; Schema: public; Owner: bojnfnlxob; Tablespace: 
--

CREATE TABLE schema_migrations (
    version character varying(255) NOT NULL
);


ALTER TABLE public.schema_migrations OWNER TO bojnfnlxob;

--
-- Name: id; Type: DEFAULT; Schema: public; Owner: bojnfnlxob
--

ALTER TABLE posts ALTER COLUMN id SET DEFAULT nextval('posts_id_seq'::regclass);


--
-- Data for Name: posts; Type: TABLE DATA; Schema: public; Owner: bojnfnlxob
--

COPY posts (id, name, message, created_at, updated_at) FROM stdin;
89	Pinky and the brain	do the same thing we don everynight Pinky. TAKE OVER THE WORLD!!1!!111!!	2010-04-06 12:08:04.40061	2010-04-06 12:08:04.40061
3	Optimus Prime	defeat the Decepticons.	2010-04-05 03:01:03.894707	2010-04-05 03:01:03.894707
5	Linh	unpack my suitcase.	2010-04-05 03:04:44.995828	2010-04-05 03:07:36.371038
90	Khoa	be inspired.	2010-04-06 12:08:30.75073	2010-04-06 12:08:30.75073
6	Jesus	come back from the dead.	2010-04-05 03:14:49.584969	2010-04-05 03:14:49.584969
91	bob	eat you	2010-04-06 12:10:51.561787	2010-04-06 12:10:51.561787
7	Frank	nap.	2010-04-05 03:26:16.337558	2010-04-05 03:26:16.337558
1	Thomson	get my act together.	2010-04-05 02:33:35.556191	2010-04-05 03:39:53.56132
8	Nang	solve the rubik's cube.	2010-04-05 03:44:08.44919	2010-04-05 03:44:49.117232
9	Gordon Brown	prepare to lose the general elections with grace.	2010-04-05 04:23:52.809506	2010-04-05 04:23:52.809506
11	Zombie Jesus	eatttttt brainsssssssssssss	2010-04-05 04:34:40.068056	2010-04-05 04:34:40.068056
12	Gordon	die.  (of laughter).	2010-04-05 05:50:48.874851	2010-04-05 05:50:48.874851
16	Angel	sleeeeeeeep. Nightie night!	2010-04-05 08:02:15.926125	2010-04-05 08:02:15.926125
18	Claire	never forget to appreciate people I care about!	2010-04-05 22:03:23.522912	2010-04-05 22:03:23.522912
19	Jaimee	pay attention in class.	2010-04-05 22:21:51.35063	2010-04-05 22:21:51.35063
20	Frank	nom nom nom.	2010-04-05 22:25:13.310502	2010-04-05 22:25:13.310502
17	Ed	update my twitter.	2010-04-05 22:01:37.29086	2010-04-06 08:49:43.301094
13	Clark Kent	for the 3201th time, muster up courage to spill my feelings to Lois.	2010-04-05 05:57:30.154929	2010-04-06 08:50:02.15277
21	Vinh	do my homework.	2010-04-06 09:47:49.462242	2010-04-06 09:47:49.462242
22	Tin	schedule a doctor's appointment (finally!)	2010-04-06 10:04:42.367607	2010-04-06 10:04:42.367607
23	T-Wut	make sure someone other than me has a good day.	2010-04-06 10:19:42.746343	2010-04-06 10:19:42.746343
24	Julie	tell my boyfriend I love him. +D	2010-04-06 10:22:15.552336	2010-04-06 10:22:15.552336
26	The Creepy Guy Across the Street on Meganslaw.ca.gov	touch you innappropriately	2010-04-06 10:27:28.886341	2010-04-06 10:27:28.886341
27	Dolph Lundgren	break you	2010-04-06 10:27:50.02082	2010-04-06 10:27:50.02082
28	T-Wut	let music elevate my mood	2010-04-06 10:28:18.433008	2010-04-06 10:28:18.433008
29	Vin Diesel	live my life one quarter mile at a time	2010-04-06 10:29:06.157453	2010-04-06 10:29:06.157453
30	Tyrannosaurus Rex	be extinct	2010-04-06 10:29:55.849115	2010-04-06 10:29:55.849115
31	Thai Red Shirts	dissolve parliament, or party in the streets of Bangkok	2010-04-06 10:31:41.945151	2010-04-06 10:31:41.945151
32	Coke Zero	give you cancer	2010-04-06 10:34:06.522775	2010-04-06 10:34:06.522775
33	Mr T	pity the fool	2010-04-06 10:34:25.240962	2010-04-06 10:34:25.240962
34	The Man	oppress the common man	2010-04-06 10:36:08.587694	2010-04-06 10:36:08.587694
35	vast and infinite	take over the world.	2010-04-06 11:12:40.814561	2010-04-06 11:12:40.814561
36	Vova	learn	2010-04-06 11:13:30.245112	2010-04-06 11:13:30.245112
37	Alex	Pwn noobs	2010-04-06 11:15:14.617796	2010-04-06 11:15:14.617796
38	Jonathan Scott	Finish chapter 3 of my annoying dissertation!	2010-04-06 11:15:15.405457	2010-04-06 11:15:15.405457
39	Kevin	stay home and masturbate all day	2010-04-06 11:15:26.33849	2010-04-06 11:15:26.33849
41	Dan	learn Rails.	2010-04-06 11:18:27.020326	2010-04-06 11:18:27.020326
43	KT	work.	2010-04-06 11:18:49.279019	2010-04-06 11:18:49.279019
44	jim	shine	2010-04-06 11:20:04.804057	2010-04-06 11:20:04.804057
48	David	Fade away..	2010-04-06 11:22:55.394904	2010-04-06 11:22:55.394904
49	Alex McLean	write about writing	2010-04-06 11:23:59.408365	2010-04-06 11:23:59.408365
55	Dram	Randify the walls	2010-04-06 11:28:20.706035	2010-04-06 11:28:20.706035
56	Roger	test this redditor's website	2010-04-06 11:29:35.187981	2010-04-06 11:29:35.187981
57	klaus	drink beer	2010-04-06 11:30:47.753211	2010-04-06 11:30:47.753211
58	Bill	beat that japanese dude at hot dog eating.	2010-04-06 11:33:18.635209	2010-04-06 11:33:18.635209
59	Andrew	study vibrations	2010-04-06 11:34:21.618182	2010-04-06 11:34:21.618182
61	bob	shit	2010-04-06 11:36:44.816366	2010-04-06 11:36:44.816366
66	Bob	kill you	2010-04-06 11:48:58.020589	2010-04-06 11:48:58.020589
67	Mei	run 4-6 miles	2010-04-06 11:49:15.245582	2010-04-06 11:49:15.245582
68	The US Military	Indiscriminately kill some civilians	2010-04-06 11:50:58.667784	2010-04-06 11:50:58.667784
69	Chris	fuck Brian	2010-04-06 11:51:42.342529	2010-04-06 11:51:42.342529
72	Emily	always remember the sacrifice of our servicemen and women.	2010-04-06 11:53:39.12589	2010-04-06 11:53:39.12589
73	bob	eat my face	2010-04-06 11:53:52.737536	2010-04-06 11:53:52.737536
74	toby	STFU	2010-04-06 11:54:16.444252	2010-04-06 11:54:16.444252
75	Tom	.	2010-04-06 11:54:44.706945	2010-04-06 11:54:44.706945
76	Piotr	test my code	2010-04-06 11:54:55.776817	2010-04-06 11:54:55.776817
77	Jimmy	wank into a hole	2010-04-06 11:57:36.301792	2010-04-06 11:57:36.301792
78	D. Howard	hack a shack	2010-04-06 11:58:01.066349	2010-04-06 11:58:01.066349
82	cougem	get fat	2010-04-06 11:58:41.36061	2010-04-06 11:58:41.36061
84	Ian	Write Software	2010-04-06 12:00:12.726126	2010-04-06 12:00:12.726126
85	Asestorian	yiff with my wolfboy-friend	2010-04-06 12:00:20.728435	2010-04-06 12:00:20.728435
94	ponzao	play futsal	2010-04-06 12:30:36.287138	2010-04-06 12:30:36.287138
97	Lola	run a fuckload.	2010-04-06 12:39:58.974713	2010-04-06 12:39:58.974713
99	Dody	cook	2010-04-06 13:13:48.780165	2010-04-06 13:13:48.780165
103	Asdf	Study Immunology	2010-04-06 13:30:40.987012	2010-04-06 13:30:40.987012
104	Death Incarnate	be the last living thing you ever see. God sent me.	2010-04-06 13:32:20.548737	2010-04-06 13:32:20.548737
107	Wilbur Bufferson	practice guitar like a metal shredder	2010-04-06 14:01:04.286545	2010-04-06 14:01:04.286545
108	Tatyana	study for my midterm.	2010-04-06 14:18:18.279739	2010-04-06 14:18:18.279739
112	Santa Claus	die!	2010-04-06 15:04:22.169461	2010-04-06 15:04:22.169461
113	wamp	wamp	2010-04-06 15:46:08.046784	2010-04-06 15:46:08.046784
114	Jameson	walk in the park	2010-04-06 16:09:30.807444	2010-04-06 16:09:30.807444
115	Jane	run, Jane, run.	2010-04-06 16:23:43.338711	2010-04-06 16:23:43.338711
116	Gordon	brighten your day.	2010-04-06 16:36:04.034841	2010-04-06 16:44:03.278991
119	Noah	fix bugs	2010-04-06 17:33:06.564282	2010-04-06 17:33:06.564282
120	Kermit the frog	make it just a little bit easier to be green.	2010-04-06 18:34:24.876072	2010-04-06 18:34:24.876072
121	Justin	watch Barca beat Arsenal!	2010-04-06 18:38:51.590633	2010-04-06 18:38:51.590633
125	bill	do stuff	2010-04-06 20:33:38.389059	2010-04-06 20:33:38.389059
126	sam	do things	2010-04-06 20:34:58.800815	2010-04-06 20:34:58.800815
127	kendrick	eat cake	2010-04-06 20:35:05.827968	2010-04-06 20:35:05.827968
101	Joshua	be joyful.  :D	2010-04-06 13:26:02.245218	2010-04-06 21:03:01.322796
130	Justin	knockout my project plan, and at least 1/3 of my law project.	2010-04-06 21:30:53.254878	2010-04-06 21:30:53.254878
131	Ladyboy Addict	kick my Thomson habit	2010-04-06 21:34:02.819925	2010-04-06 21:34:02.819925
132	Someone	Try this application	2010-04-06 21:42:26.993182	2010-04-06 21:42:26.993182
133	Michael J. Fox	take a picture without using a tripod.	2010-04-06 21:54:48.98547	2010-04-06 21:54:48.98547
134	0102 ,60 lirpA 	lliw I ,yodat	2010-04-06 22:29:11.598192	2010-04-06 22:29:11.598192
135	Post #135	be post number 135.	2010-04-06 22:30:37.941202	2010-04-06 22:30:37.941202
136	Thomson	find a way to refresh the posts without refreshing the page. I'm still new at this!	2010-04-06 23:41:03.018734	2010-04-06 23:41:03.018734
137	cookie monster	eat cookies!	2010-04-06 23:46:03.674667	2010-04-06 23:46:03.674667
138	Jen	catch up on my emails	2010-04-06 23:46:44.430929	2010-04-06 23:46:44.430929
139	Linh	tryruby	2010-04-07 01:34:50.793671	2010-04-07 01:34:50.793671
140	theonlydayistoday.com	work on the Droid.	2010-04-07 01:38:42.947154	2010-04-07 01:38:42.947154
141	Veronica	have anal sex.	2010-04-07 05:30:06.666859	2010-04-07 05:30:06.666859
142	Thomson	remember to go to the laundromat.	2010-04-07 06:46:48.419741	2010-04-07 06:46:48.419741
143	Trollface	say "PROBLEM ??"	2010-04-07 13:05:43.725329	2010-04-07 13:05:43.725329
144	poon	ream you	2010-04-07 16:46:04.854772	2010-04-07 16:46:04.854772
145	Chase	Love	2010-04-07 17:52:13.445422	2010-04-07 17:52:13.445422
146	Ed	finish grading one English 10 project.	2010-04-07 18:29:06.631538	2010-04-07 18:29:06.631538
147	Anne	go for quality AND quantity.	2010-04-07 19:13:14.255514	2010-04-07 19:13:14.255514
148	Russell	be	2010-04-07 19:53:38.399692	2010-04-07 19:53:38.399692
150	Neil	have a beer, then have a nap	2010-04-07 20:21:29.108793	2010-04-07 20:21:29.108793
152	Tiny Turtle	gib some guys	2010-04-07 20:53:34.081041	2010-04-07 20:53:34.081041
153	Alfredo	support Benfica.	2010-04-07 22:29:52.809408	2010-04-07 22:29:52.809408
154	possibly-addicted	masturbate less than 5 times	2010-04-07 22:31:08.205521	2010-04-07 22:31:08.205521
155	jorge	conquer the world	2010-04-07 22:56:14.25806	2010-04-07 22:56:14.25806
157	Jon	actually get some work done	2010-04-07 23:14:37.835972	2010-04-07 23:14:37.835972
158	Sebastian Paaske Tørholm	avoid doing what can be done tomorrow.	2010-04-07 23:28:33.913608	2010-04-07 23:28:33.913608
159	Brandon	read 5 papers.	2010-04-08 01:28:38.719444	2010-04-08 01:28:38.719444
160	Grayson Villanueva	be strong.	2010-04-08 01:53:40.147332	2010-04-08 01:53:40.147332
161	Brain	do the same thing I do every night.	2010-04-08 04:29:30.799889	2010-04-08 04:29:30.799889
162	Death	Live	2010-04-08 06:37:28.519966	2010-04-08 06:37:28.519966
165	Florian S.	build a rocket to go to the moon	2010-04-08 10:40:48.200082	2010-04-08 10:40:48.200082
166	John	Work all day long	2010-04-08 12:03:16.548075	2010-04-08 12:03:16.548075
167	J. Random Hacker	put content on the domains I own	2010-04-08 13:23:20.022863	2010-04-08 13:23:20.022863
168	George	save the world	2010-04-08 16:22:29.592648	2010-04-08 16:22:29.592648
169	Ferd	keep learning Scheme	2010-04-08 17:17:11.913203	2010-04-08 17:17:11.913203
170	<script>alert('javascript')</script>	<!-- test your code --> \\";alert('XSS');//	2010-04-08 17:22:44.275627	2010-04-08 17:22:44.275627
171	Jack Taylor	reestablish contact with my dad after 20 years of being angry at him for leaving home. I want to love you dad.	2010-04-08 17:31:14.902869	2010-04-08 18:04:59.489049
172	Claudia	get my 2k split under 1:50	2010-04-08 18:07:30.087944	2010-04-08 18:07:30.087944
151	Grubert Mcburrough	be alone	2010-04-07 20:52:38.727789	2010-04-08 18:22:21.735265
173	your Mom	continue being disappointed in my son.	2010-04-08 20:51:07.138455	2010-04-08 20:51:07.138455
174	The Nightman	pay the troll toll	2010-04-08 21:34:19.557414	2010-04-08 21:34:19.557414
175	Linh	make my grad school decision official	2010-04-08 21:47:44.568851	2010-04-08 21:47:44.568851
176	LtAdm	take down the Westboro Baptist Church.	2010-04-08 23:45:39.380387	2010-04-08 23:45:39.380387
177	Jon	teach myself a new tool.	2010-04-09 10:32:20.054313	2010-04-09 10:32:20.054313
178	JOn	learn to finish typing a goddamn sentence or 	2010-04-09 10:33:25.052867	2010-04-09 10:33:25.052867
179	chris simmons	write my apprasil	2010-04-09 12:18:15.072519	2010-04-09 12:18:15.072519
180	rb	be awesome	2010-04-09 16:44:33.297986	2010-04-09 16:44:33.297986
181	Nick	fuck your mother	2010-04-09 20:30:51.86568	2010-04-09 20:30:51.86568
183	goatse	<img src="http://www.goatsevideo.com/images/goatse-original.jpg">	2010-04-09 20:33:44.219137	2010-04-09 20:33:44.219137
184	Steven	not call out Thomson's name while making love to someone else.	2010-04-09 22:26:13.343886	2010-04-09 22:26:13.343886
185	Thorny	be all that is man!	2010-04-09 22:30:42.428695	2010-04-09 22:30:42.428695
187	Bob	walk down the hill	2010-04-10 17:35:18.123293	2010-04-10 17:35:18.123293
188	John Cracker	Fuck things	2010-04-11 02:40:24.266179	2010-04-11 02:40:24.266179
190	Ferd	eat cat food.	2010-04-11 16:17:24.474	2010-04-11 16:17:24.474
194	Nelville Flynn	get these motherfucking snakes off this motherfucking plane! 	2010-04-11 20:55:34.628629	2010-04-11 20:55:34.628629
186	Bill	check out a new rails app	2010-04-10 03:28:04.523069	2010-04-12 01:10:02.194756
\.


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: public; Owner: bojnfnlxob
--

COPY schema_migrations (version) FROM stdin;
20100405020356
\.


--
-- Name: posts_pkey; Type: CONSTRAINT; Schema: public; Owner: bojnfnlxob; Tablespace: 
--

ALTER TABLE ONLY posts
    ADD CONSTRAINT posts_pkey PRIMARY KEY (id);


--
-- Name: unique_schema_migrations; Type: INDEX; Schema: public; Owner: bojnfnlxob; Tablespace: 
--

CREATE UNIQUE INDEX unique_schema_migrations ON schema_migrations USING btree (version);


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

