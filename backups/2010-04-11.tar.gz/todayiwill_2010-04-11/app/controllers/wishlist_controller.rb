class WishlistController < ApplicationController
  def index
  end

end
